


function Login(){
    return(
        <h1>Login page teacher</h1>
    )
}

export default Login