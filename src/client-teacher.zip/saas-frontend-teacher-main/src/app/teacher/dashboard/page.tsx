

function TeacherDashboard(){
    return(
        <h1>Teacher Dashboard</h1>
    )
}

export default TeacherDashboard