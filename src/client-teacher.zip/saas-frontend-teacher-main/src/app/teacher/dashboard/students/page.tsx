

function TeacherStudent(){
    return(
        <h1>Teacher student</h1>
    )
}