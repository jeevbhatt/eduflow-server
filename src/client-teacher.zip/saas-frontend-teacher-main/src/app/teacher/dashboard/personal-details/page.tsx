


function PersonalDetails(){
    return(
        <h1>Personal Details page</h1>
    )
}

export default PersonalDetails