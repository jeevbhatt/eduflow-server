


function TeacherCourse(){
    return(
        <h1>Teacher Course</h1>
    )
}


export default TeacherCourse