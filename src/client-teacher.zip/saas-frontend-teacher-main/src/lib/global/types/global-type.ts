


export enum Status{
    SUCCESS = "success", 
    ERROR = "error", 
    LOADING = "loading"
}